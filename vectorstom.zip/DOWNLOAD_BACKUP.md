# Скачивание бэкапа с Яндекс.Диска на сервер

## 📦 Бэкап на Яндекс.Диске

**Ссылка:** https://disk.yandex.ru/d/8-wECwCh76azSg

---

## 🔗 Получение прямой ссылки

### Способ 1: Через веб-интерфейс (рекомендуется)

1. Откройте ссылку: https://disk.yandex.ru/d/8-wECwCh76azSg
2. Нажмите кнопку **"Скачать"** правой кнопкой мыши
3. Выберите **"Копировать адрес ссылки"**
4. Получите прямую ссылку вида:
   ```
   https://downloader.disk.yandex.ru/disk/...
   ```

### Способ 2: Через Яндекс.Диск API (автоматически)

На вашем сервере выполните:

```bash
# Получить прямую ссылку на скачивание
curl -s "https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key=https://disk.yandex.ru/d/8-wECwCh76azSg" | grep -o '"href":"[^"]*"' | sed 's/"href":"//;s/"//' | sed 's/\\//g'
```

Эта команда вернет прямую ссылку для wget.

---

## 📥 Скачивание на сервер

После подключения к серверу:

```bash
cd /root/vectorstom

# Вариант А: Если у вас есть прямая ссылка
wget -O qdrant-backup.tar.gz "https://downloader.disk.yandex.ru/disk/..."

# Вариант Б: Автоматическое получение ссылки и скачивание
DIRECT_URL=$(curl -s "https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key=https://disk.yandex.ru/d/8-wECwCh76azSg" | grep -o '"href":"[^"]*"' | sed 's/"href":"//;s/"//' | sed 's/\\//g')
wget -O qdrant-backup.tar.gz "$DIRECT_URL"

# Проверка размера (должно быть ~10 МБ)
ls -lh qdrant-backup.tar.gz
```

---

## ✅ Проверка целостности

После скачивания проверьте файл:

```bash
# Размер должен быть ~9.69 МБ
du -h qdrant-backup.tar.gz

# Проверка содержимого архива
tar -tzf qdrant-backup.tar.gz | head -20

# Должны увидеть файлы вида:
# qdrant/storage/collections/...
# qdrant/storage/meta.json
```

---

## 🔄 Альтернатива: curl вместо wget

Если wget не установлен:

```bash
# Установить wget
apt install wget -y

# Или использовать curl
DIRECT_URL=$(curl -s "https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key=https://disk.yandex.ru/d/8-wECwCh76azSg" | grep -o '"href":"[^"]*"' | sed 's/"href":"//;s/"//' | sed 's/\\//g')
curl -L "$DIRECT_URL" -o qdrant-backup.tar.gz
```

---

## 📋 Упрощенная команда (одна строка)

```bash
curl -s "https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key=https://disk.yandex.ru/d/8-wECwCh76azSg" | grep -o '"href":"[^"]*"' | sed 's/"href":"//;s/"//' | sed 's/\\//g' | xargs wget -O qdrant-backup.tar.gz
```

---

## 🆘 Если ссылка не работает

### Проблема: "Permission denied" или "403"
Ссылка может быть приватной. Решение:

1. Откройте https://disk.yandex.ru/d/8-wECwCh76azSg
2. Убедитесь, что доступ **"Публичный"**
3. Если нет - нажмите "Поделиться" → "Публичная ссылка"

### Проблема: Яндекс.Диск API не возвращает ссылку
Альтернатива - скачать вручную:

1. На компьютере скачайте файл с Яндекс.Диска
2. Используйте WinSCP для загрузки на сервер
3. Или используйте `scp`:
   ```powershell
   scp qdrant-backup.tar.gz root@<IP>:/root/vectorstom/
   ```

---

## ✅ После успешного скачивания

Продолжайте с **Шага 5** в файле `DEPLOY_FROM_GITHUB.md`:

```bash
# Создаем volume
docker volume create vectorstom_qdrant_data

# Восстанавливаем из бэкапа
docker run --rm \
  -v vectorstom_qdrant_data:/qdrant/storage \
  -v /root/vectorstom/qdrant-backup.tar.gz:/backup.tar.gz \
  alpine sh -c "cd / && tar -xzf /backup.tar.gz"
```

---

## 💡 Совет

Яндекс.Диск - удобный способ передачи файлов на сервер:
- Не нужно держать компьютер включенным для scp
- Не нужно настраивать WinSCP
- Можно скачать с любого сервера в любое время

**Ссылка на бэкап:** https://disk.yandex.ru/d/8-wECwCh76azSg

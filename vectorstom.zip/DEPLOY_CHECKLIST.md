# Чеклист быстрого развертывания VectorStom

## ☑️ До развертывания (на вашем компьютере)

### 1. Создать бэкап векторов
```powershell
cd "E:\СТОМПРАКТИКА ПРОЕКТЫ\Docling"
docker compose exec qdrant tar -czf /tmp/qdrant-backup.tar.gz /qdrant/storage
docker compose cp qdrant:/tmp/qdrant-backup.tar.gz ./qdrant-backup.tar.gz
```
✅ Файл `qdrant-backup.tar.gz` создан (~50-100 МБ)

### 2. Создать .env файл
```
POLZA_API_KEY=ak_VdTnWuDz1CZGLuiiRH5qt34PlZQYx0NqROscaGPneIY
```
✅ Файл `.env.prod` создан

### 3. Проверить необходимые файлы
- ✅ `webapp/` (папка с кодом)
- ✅ `docker-compose.simple-prod.yml`
- ✅ `nginx-simple.conf`
- ✅ `.env.prod`
- ✅ `qdrant-backup.tar.gz`

---

## ☑️ Заказ сервера

### Параметры VPS
- ✅ **Провайдер:** Timeweb / VK Cloud / Yandex Cloud
- ✅ **Тариф:** High C1-M2-D20 (1 100 ₽/мес)
- ✅ **ОС:** Ubuntu 24.04 LTS
- ✅ **Регион:** Москва-2 (минимальная задержка)

### После создания
- ✅ IP адрес получен: `_______________`
- ✅ SSH доступ работает: `ssh root@<IP>`

---

## ☑️ Настройка сервера (SSH)

### Установка Docker
```bash
apt update && apt upgrade -y
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
apt install docker-compose -y
```
✅ Docker установлен: `docker --version`

### Настройка firewall
```bash
apt install ufw -y
ufw allow 22/tcp
ufw allow 80/tcp
ufw enable
```
✅ Firewall настроен

---

## ☑️ Загрузка проекта

### С компьютера на сервер (Windows PowerShell)
```powershell
# Используйте WinSCP или pscp из PuTTY
# Или через WSL/Git Bash:
scp qdrant-backup.tar.gz root@<IP>:/root/
scp -r webapp root@<IP>:/root/
scp docker-compose.simple-prod.yml root@<IP>:/root/
scp nginx-simple.conf root@<IP>:/root/
scp .env.prod root@<IP>:/root/.env
```
✅ Все файлы загружены на сервер

---

## ☑️ Запуск (на сервере)

### 1. Восстановить векторы
```bash
cd /root
docker volume create vectorstom_qdrant_data
docker run --rm \
  -v vectorstom_qdrant_data:/qdrant/storage \
  -v /root/qdrant-backup.tar.gz:/backup.tar.gz \
  alpine sh -c "cd / && tar -xzf /backup.tar.gz"
```
✅ Векторы восстановлены

### 2. Загрузить переменные окружения
```bash
export $(cat /root/.env | xargs)
```
✅ `POLZA_API_KEY` загружен

### 3. Запустить контейнеры
```bash
docker-compose -f docker-compose.simple-prod.yml up -d
```
✅ Контейнеры запущены: `docker ps` (4 контейнера)

### 4. Загрузить модель Ollama
```bash
docker exec vectorstom-ollama ollama pull nomic-embed-text
```
✅ Модель загружена (~275 МБ)

---

## ☑️ Проверка работы

### Health checks
```bash
curl http://localhost/health              # OK
curl http://localhost/api/stats           # {qdrant: {vectors_count: 902}}
curl http://localhost/api/documents       # [{...}, {...}, {...}]
```
✅ Все эндпоинты отвечают

### Из браузера
- ✅ Открыть `http://<IP_СЕРВЕРА>`
- ✅ Интерфейс VectorStom загружается
- ✅ Список документов отображается (3 документа, 902 вектора)
- ✅ Тестовый вопрос работает: "Что такое нормочас?"

---

## ☑️ Финальная проверка

### Тестирование с нескольких устройств
- ✅ С телефона (мобильная версия)
- ✅ С компьютера коллеги
- ✅ 2-3 одновременных запроса работают

### Тест параллельности (ВАЖНО!)
```bash
# Откройте 3 вкладки браузера
# Задайте вопросы ОДНОВРЕМЕННО во всех вкладках
# Ожидаемый результат: все 3 ответа за ~5 секунд
```
- ✅ Параллельная обработка работает (4 worker'а Gunicorn)

### Производительность
- ✅ Время ответа: 3-5 секунд
- ✅ Поиск векторов: <100 мс
- ✅ RAM usage: ~1.5 ГБ (проверить: `docker stats`)

---

## 🎉 Развертывание завершено!

**Доступ к системе:** `http://<IP_СЕРВЕРА>`

**Для коллег:**
Отправьте ссылку `http://<IP_СЕРВЕРА>` для тестирования

**Мониторинг:**
```bash
# Логи
docker logs -f vectorstom-webapp

# Статистика
docker stats

# Перезапуск при проблемах
docker-compose -f docker-compose.simple-prod.yml restart
```

---

## 📋 Следующие шаги (опционально)

- [ ] Привязать домен (vectorstom.ru)
- [ ] Установить SSL сертификат
- [ ] Настроить автоматические бэкапы
- [ ] Добавить базовую авторизацию
- [ ] Настроить мониторинг (Grafana)

---

## 💰 Ежемесячные расходы

- Сервер C1-M2-D20: **1 100 ₽/мес**
- API Polza.ai (~1000 запросов): **~180 ₽/мес**
- **ИТОГО: ~1 300 ₽/мес**

---

## 🆘 Если что-то не работает

1. **Проверить логи:** `docker logs -f vectorstom-webapp`
2. **Проверить статус:** `docker ps -a`
3. **Перезапустить:** `docker-compose -f docker-compose.simple-prod.yml restart`
4. **Полная перезагрузка сервера:** `reboot`

**Контакты для поддержки:** [ваша почта]
